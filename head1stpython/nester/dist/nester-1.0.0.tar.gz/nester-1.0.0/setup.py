from distutils.core import setup

setup(
    name            = 'nester',
    version         = '1.0.0',
    py_modules      = ['nester'],
    author          = 'israelzuniga',
    author_email    = 'hola@israelzuniga.com',
    url             = 'http://israelzuniga.com',
    description     = 'A simple printer of nested lists',
    )
